import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:hozzo/app/asset_data.dart';
import 'package:hozzo/ui/smart_widgets/primary_app_bar/primary_app_bar_viewmodel.dart';
import 'package:stacked/stacked.dart';

class PrimaryAppBar extends StatelessWidget implements PreferredSizeWidget {
  final GlobalKey<ScaffoldState> scaffoldKey;

  const PrimaryAppBar(this.scaffoldKey, {Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PrimaryAppBarViewModel>.reactive(
      builder: (context, model, child) => AppBar(
        backgroundColor: Colors.transparent,
        automaticallyImplyLeading: false,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 15),
          child: IconButton(
            icon: SvgPicture.asset(AppIcons.menu),
            onPressed: model.openDrawer,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: IconButton(
              icon: SvgPicture.asset(AppIcons.comment),
              onPressed: model.goToSelectVehicleView,
            ),
          )
        ],
      ),
      viewModelBuilder: () => PrimaryAppBarViewModel(scaffoldKey),
    );
  }

  @override
  Size get preferredSize => new Size.fromHeight(kToolbarHeight);
}
