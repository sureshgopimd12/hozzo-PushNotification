class Onboard {
  final String imageUrl;
  final String title;
  final String description;

  const Onboard({this.imageUrl, this.title, this.description});
}
